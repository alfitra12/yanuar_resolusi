<?php
session_start();
$koneksi=new mysqli("localhost","root","","db_alfitrayanuar");
?>